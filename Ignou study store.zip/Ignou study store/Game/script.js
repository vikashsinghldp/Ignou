// script.js

const car = document.getElementById('car');
const road = document.getElementById('road');
const scoreDisplay = document.getElementById('score');
const obstacleContainer = document.getElementById('obstacle-container');

const leftButton = document.getElementById('left');
const rightButton = document.getElementById('right');
const upButton = document.getElementById('up');
const downButton = document.getElementById('down');

let carPosition = {
  x: 175, // initial left position (centered)
  y: 500  // initial bottom position
};

const carSpeed = 10;
let score = 0;
let obstacles = [];
let gameInterval;
let obstacleInterval;

// Function to move the car
function moveCar() {
  car.style.left = carPosition.x + 'px';
  car.style.bottom = carPosition.y + 'px';
}

// Function to generate random obstacles
function generateObstacle() {
  const obstacle = document.createElement('div');
  obstacle.classList.add('obstacle');
  obstacle.style.left = `${Math.random() * (road.offsetWidth - 50)}px`; // Random x-position
  obstacleContainer.appendChild(obstacle);
  obstacles.push(obstacle);
}

// Function to move obstacles
function moveObstacles() {
  obstacles.forEach((obstacle, index) => {
    let obstaclePosition = obstacle.getBoundingClientRect();
    obstacle.style.top = (parseInt(obstacle.style.top || 0) + 5) + 'px'; // Move obstacle down

    // If the obstacle reaches the bottom of the road, remove it
    if (obstaclePosition.top > road.offsetHeight) {
      obstacle.remove();
      obstacles.splice(index, 1);
      score++; // Increase score
      scoreDisplay.textContent = `Score: ${score}`;
    }

    // Collision detection
    if (checkCollision(car, obstacle)) {
      alert(`Game Over! Final Score: ${score}`);
      clearInterval(gameInterval);
      clearInterval(obstacleInterval);
    }
  });
}

// Function to check for collision between the car and an obstacle
function checkCollision(car, obstacle) {
  const carRect = car.getBoundingClientRect();
  const obstacleRect = obstacle.getBoundingClientRect();

  return !(
    carRect.top > obstacleRect.bottom ||
    carRect.bottom < obstacleRect.top ||
    carRect.left > obstacleRect.right ||
    carRect.right < obstacleRect.left
  );
}

// Handle controls for movement
leftButton.addEventListener('click', () => {
  if (carPosition.x > 0) {
    carPosition.x -= carSpeed;
    moveCar();
  }
});

rightButton.addEventListener('click', () => {
  if (carPosition.x < road.offsetWidth - car.offsetWidth) {
    carPosition.x += carSpeed;
    moveCar();
  }
});

upButton.addEventListener('click', () => {
  if (carPosition.y < road.offsetHeight - car.offsetHeight) {
    carPosition.y += carSpeed;
    moveCar();
  }
});

downButton.addEventListener('click', () => {
  if (carPosition.y > 0) {
    carPosition.y -= carSpeed;
    moveCar();
  }
});

// Handle keyboard controls
document.addEventListener('keydown', (e) => {
  switch (e.key) {
    case 'ArrowLeft':
      if (carPosition.x > 0) {
        carPosition.x -= carSpeed;
        moveCar();
      }
      break;
    case 'ArrowRight':
      if (carPosition.x < road.offsetWidth - car.offsetWidth) {
        carPosition.x += carSpeed;
        moveCar();
      }
      break;
    case 'ArrowUp':
      if (carPosition.y < road.offsetHeight - car.offsetHeight) {
        carPosition.y += carSpeed;
        moveCar();
      }
      break;
    case 'ArrowDown':
      if (carPosition.y > 0) {
        carPosition.y -= carSpeed;
        moveCar();
      }
      break;
  }
});

// Start the game
function startGame() {
  gameInterval = setInterval(moveObstacles, 20); // Move obstacles every 20ms
  obstacleInterval = setInterval(generateObstacle, 2000); // Generate new obstacles every 2 seconds
}

moveCar();
startGame();
